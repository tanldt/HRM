﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using iHRPCore;
using iHRPCore.Com;
using FPTToolWeb.Exports;

namespace iHRPCore.Temp
{
	/// <summary>
	/// Summary description for TestReportPaySlip.
	/// </summary>
	public class TestReportPaySlip : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button Button1;
		//Word.Application wrdApp;
		//Word._Document wrdDoc;
		Object oMissing = System.Reflection.Missing.Value;
		protected System.Web.UI.WebControls.Button Button2;
		protected System.Web.UI.WebControls.Button Button4;
		protected System.Web.UI.WebControls.Button cmdCV;
		protected System.Web.UI.WebControls.TextBox txtResult;
		protected System.Web.UI.WebControls.Button cmdExport;
		Object oFalse = false;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
//			SqlDataAdapter DA = new SqlDataAdapter("SELECT top 100 * FROM HR_vEmpList", ConfigurationSettings.AppSettings("ConnString"));
//			DataSet DS = new DataSet();
//			DA.Fill(DS, "HR_vEmpList");
//			// TODO: NotImplemented statement: ICSharpCode.SharpRefactory.Parser.AST.VB.ReDimStatement
			
//			dgSales.DataSource = clsCommon.GetDataTable("SELECT top 100 * FROM HR_vEmpList");
//			dgSales.DataBind();
		}
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.Button4.Click += new System.EventHandler(this.Button4_Click);
			this.cmdCV.Click += new System.EventHandler(this.Button3_Click);
			this.Button2.Click += new System.EventHandler(this.Button2_Click);
			this.cmdExport.Click += new System.EventHandler(this.cmdExport_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Button1_Click(object sender, System.EventArgs e)
		{
			string strFileTemplate = "";
			string strDate = "";
			//string strImage = ConfigurationSettings.AppSettings["pStrimageReport"].Trim();
			//string strImage = "http://localhost/iHRP_SCR/Upload/TemplateReport/Image/image001.jpg";
			DataTable dt = clsCommon.GetDataTable("SELECT top 10 * FROM HR_vEmpList");
			
			strFileTemplate = "test.htm";

			try 
			{
				string strHeaderParams = "";
				string strHeaderValues = "";
				string strFooterParams = "";
				string strFooterValues = "";
				//Phan khai bao se dung Tool bao cao Excel
				#region Header 
				strHeaderParams = "";
				strHeaderValues = "";
				#endregion
				#region Footer
				strDate = DateTime.Now.ToString("dd/MM/yyyy");
				strFooterParams = "Date";					
				strFooterValues = strDate;
				#endregion
				
				FPTToolWeb.Reports.v10.clsBaocao bc = new FPTToolWeb.Reports.v10.clsBaocao();
				#region Config Basic
				bc.sfileTemplate = strFileTemplate;
				string strReports = bc.strReportPageDoc(dt);
				#endregion
				//End
				ExcelExporter myExcelXport=new ExcelExporter(this.Page);
				myExcelXport.ExportHTMLTo(strReports,"word");
				myExcelXport = null;
			}
			catch//(Exception ex)
			{										
				//lblErr.Text = ex.Message;
			}
			finally
			{	
				dt.Dispose();
			}
			// Create an instance of Word  and make it visible.
//			wrdApp = new Word.Application();
//			wrdApp.Visible = true;
//			Word.Document myMergeDocument;
//
//			string strFileName = "c:\\template.doc";
//			string strDataFile = "c:\\datafile.xls";
//
//			object filename = strFileName;
//			object objTrue = true;
//			object objFalse = false;
//			object objMiss = Type.Missing;
//
//
//			//Open merge document
//			myMergeDocument = wrdApp.Documents.Open(ref filename, ref objMiss, ref objMiss, ref objMiss, ref objMiss, ref objMiss, ref objMiss, ref objMiss, ref objMiss, ref objMiss, ref objMiss, ref objMiss, ref objMiss, ref objMiss, ref objMiss, ref objMiss);
//			myMergeDocument.Select();
//
//           
//
//			//Open the data source
//			object source = strDataFile;
//			object format = Word.WdOpenFormat.wdOpenFormatAuto;
//			myMergeDocument.MailMerge.OpenDataSource(strDataFile, ref format, ref objFalse, ref objMiss, ref objTrue, ref objFalse, ref objMiss, ref objMiss, ref objMiss, ref objMiss, ref objMiss, ref objMiss, ref objMiss, ref objMiss, ref objMiss, ref objMiss);
//
//			//Perform Merge
//			myMergeDocument.MailMerge.Destination = Word.WdMailMergeDestination.wdSendToNewDocument;
//
//           
//			myMergeDocument.MailMerge.SuppressBlankLines = true;
//			myMergeDocument.MailMerge.DataSource.FirstRecord = (int)Word.WdMailMergeDefaultRecord.wdDefaultFirstRecord;
//			myMergeDocument.MailMerge.DataSource.LastRecord = (int)Word.WdMailMergeDefaultRecord.wdDefaultLastRecord;
//			myMergeDocument.MailMerge.Execute(ref objFalse);
//
//			// Close the original form document.
//			myMergeDocument.Saved = true;
//			myMergeDocument.Close(ref oFalse,ref oMissing,ref oMissing);
		}

		private void Button2_Click(object sender, System.EventArgs e)
		{
			DataTable dt= clsCommon.GetDataTable("SELECT top 10 CompanyEN, Level1EN, * FROM HR_vEmpList");

			//Phan khai bao se dung Tool bao cao Excel
			FPTToolWeb.Reports.v10.clsBaocao bc = new FPTToolWeb.Reports.v10.clsBaocao();
			#region Header Company Info
				
			string strHeaderParams = "Title";
			string strHeaderValues = "Test";

			#endregion
			#region Footer
			string strFooterParams = "CountEmp";
			string strFooterValues ="";
			if (dt != null)
				strFooterValues = dt.Rows.Count.ToString();
			else
				strFooterValues = "0";
			#endregion
			#region Config System
			/*
				 * itempheadlv1: id cho Header Group 1
				 * itempheadlv2: id cho Header Group 2
				 * itempsumlv1: id sum cap 1
				 * itempsumlv2: id sum cap 2
				 * itempsumtotal: id sum tong cong tat ca
				 * */
			#endregion
			#region Config Basic
			bc.IsGroupLv1 = true; //Co Group 1 khong?
			bc.GroupLv1 = 1; //Chỉ định Group level 1 ở cột thứ I
			bc.IsGroupLv2 = true; //Co Group 2 khong?
			bc.GroupLv2 = 2; //Chỉ định Group level 2 ở cột thứ II
			bc.IsSum = true; //Có Sum tong hay không? Nếu có thì phải có id template (itempsumtotal) đi kèm
			bc.IsSum1 = true; //Có Sum cap 1 hay không? Nếu có thì phải có id template (itempsumlv1) đi kèm
			bc.IsSum2 = true; //Có Sum cap 2 hay không? Nếu có thì phải có id template (itempsumlv2) đi kèm
			bc.sfileTemplate = "HR_sprptMale.htm";
			bc.sHeaderParams = strHeaderParams;
			bc.sHeaderValues = strHeaderValues;
			bc.sFooterParams = strFooterParams;
			bc.sFooterValues = strFooterValues;
			
			string strReports = bc.strReportBasic(dt);
			#endregion
			
			ExcelExporter myExcelXport=new ExcelExporter(this.Page);
			myExcelXport.ExportHTMLToExcel(strReports,"Excel");
			myExcelXport = null;
		}

		private void Button3_Click(object sender, System.EventArgs e)
		{
			string strFileTemplate = "";
			string strDate = "";
			//string strImage = ConfigurationSettings.AppSettings["pStrimageReport"].Trim();
			//string strImage = "http://localhost/iHRP_SCR/Upload/TemplateReport/Image/image001.jpg";
			DataTable dt = clsCommon.GetDataTable("SELECT top 10 * FROM HR_vEmpList");
			
			strFileTemplate = "testCV.htm";

			try 
			{
				string strHeaderParams = "";
				string strHeaderValues = "";
				string strFooterParams = "";
				string strFooterValues = "";
				//Phan khai bao se dung Tool bao cao Excel
				#region Header 
				strHeaderParams = "";
				strHeaderValues = "";
				#endregion
				#region Footer
				strDate = DateTime.Now.ToString("dd/MM/yyyy");
				strFooterParams = "Date";					
				strFooterValues = strDate;
				#endregion
				
				FPTToolWeb.Reports.v10.clsBaocao bc = new FPTToolWeb.Reports.v10.clsBaocao();
				#region Config Basic
				bc.sfileTemplate = strFileTemplate;
				#region Sub report
				bc.dtSubReport1 = clsDB.GetDataTable("select EmpID, FirstName + ' ' + LastName as [FullName] from HR_tblRelative");
				bc.sItemLink1 = "EmpID";
				
                bc.dtSubReport2 = clsDB.GetDataTable("select EmpID, FirstName + ' ' + LastName as [FullName] from HR_tblRelative");
                bc.sItemLink2 = "EmpID";
				#endregion
				string strReports = bc.strReportPageDoc(dt);
				#endregion
				//End
				txtResult.Text = strReports;
				ExcelExporter myExcelXport=new ExcelExporter(this.Page);
				myExcelXport.ExportHTMLTo(strReports,"doc");
				myExcelXport = null;
			}
			catch//(Exception ex)
			{										
				//lblErr.Text = ex.Message;
			}
			finally
			{	
				dt.Dispose();
			}
		}

		private void Button4_Click(object sender, System.EventArgs e)
		{
			DataTable dt= clsCommon.GetDataTable("SELECT top 10 CompanyEN, Level1EN, * FROM HR_vEmpList");

			//Phan khai bao se dung Tool bao cao Excel
			FPTToolWeb.Reports.v10.clsBaocao bc = new FPTToolWeb.Reports.v10.clsBaocao();
			#region Header Company Info
				
			string strHeaderParams = "Title";
			string strHeaderValues = "Test";

			#endregion
			#region Footer
			string strFooterParams = "CountEmp";
			string strFooterValues ="";
			if (dt != null)
				strFooterValues = dt.Rows.Count.ToString();
			else
				strFooterValues = "0";
			#endregion
			#region Config System
			/*
				 * itempheadlv1: id cho Header Group 1
				 * itempheadlv2: id cho Header Group 2
				 * itempsumlv1: id sum cap 1
				 * itempsumlv2: id sum cap 2
				 * itempsumtotal: id sum tong cong tat ca
				 * */
			#endregion
			#region Config Basic
			bc.IsGroupLv1 = true; //Co Group 1 khong?
			bc.GroupLv1 = 1; //Chỉ định Group level 1 ở cột thứ I
			bc.IsGroupLv2 = true; //Co Group 2 khong?
			bc.GroupLv2 = 2; //Chỉ định Group level 2 ở cột thứ II
			bc.IsSum = true; //Có Sum tong hay không? Nếu có thì phải có id template (itempsumtotal) đi kèm
			bc.IsSum1 = true; //Có Sum cap 1 hay không? Nếu có thì phải có id template (itempsumlv1) đi kèm
			bc.IsSum2 = true; //Có Sum cap 2 hay không? Nếu có thì phải có id template (itempsumlv2) đi kèm
			bc.sfileTemplate = "HR_sprptMale.htm";
			bc.sHeaderParams = strHeaderParams;
			bc.sHeaderValues = strHeaderValues;
			bc.sFooterParams = strFooterParams;
			bc.sFooterValues = strFooterValues;
			
			string strReports = bc.strReportBasic(dt);
			#endregion
			strReports = strReports + bc.sBreakPage + strReports;
			ExcelExporter myExcelXport=new ExcelExporter(this.Page);
			myExcelXport.ExportHTMLToExcel(strReports,"doc");
			myExcelXport = null;
		}

		private void cmdExport_Click(object sender, System.EventArgs e)
		{
			//txtResult.Text = strReports;
			ExcelExporter myExcelXport=new ExcelExporter(this.Page);
			myExcelXport.ExportHTMLTo(txtResult.Text,"doc");
			myExcelXport = null;
		}

	}
}
